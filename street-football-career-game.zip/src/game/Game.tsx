import { useCallback, useEffect, useRef, useState } from "react";
import {
  type Division,
  type GameResult,
  type Profile,
  type ScoreEntry,
  type Signature,
  type Teammate,
  celebrationFor,
  effectFor,
  formatNumber,
} from "../lib/data";
import { playSound, setSoundEnabled, unlockAudio } from "../lib/audio";
import { StreetKingsEngine, type HudState } from "./engine";
import { Icon } from "../components/Icons";

export interface MatchReward {
  coins: number;
  xp: number;
  trophy: string | null;
  personalBest: boolean;
  rank: number;
}

interface GameProps {
  division: Division;
  profile: Profile;
  teammate?: Teammate;
  signature: Signature;
  sound: boolean;
  scores: ScoreEntry[];
  onResult: (result: GameResult) => MatchReward;
  onExit: () => void;
  onToggleSound: () => void;
}

const INITIAL_HUD: HudState = {
  status: "countdown",
  timeLeft: 60,
  score: 0,
  goals: 0,
  target: 4,
  combo: 0,
  multiplier: 1,
  skill: 100,
  skillReady: true,
  announcement: null,
  celebration: null,
  signatureUses: 0,
  possession: true,
  rocketArmed: false,
  opponent: "",
};

export function GameMatch({
  division,
  profile,
  teammate,
  signature,
  sound,
  scores,
  onResult,
  onExit,
  onToggleSound,
}: GameProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<StreetKingsEngine | null>(null);
  const onResultRef = useRef(onResult);
  const [hud, setHud] = useState<HudState>(INITIAL_HUD);
  const [outcome, setOutcome] = useState<{ result: GameResult; reward: MatchReward } | null>(null);
  const [restartKey, setRestartKey] = useState(0);

  useEffect(() => {
    onResultRef.current = onResult;
  }, [onResult]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new StreetKingsEngine(
      canvas,
      { division, signature, teammate, sound },
      {
        onHud: (next) => setHud(next),
        onEnd: (result) => {
          const reward = onResultRef.current(result);
          setOutcome({ result, reward });
        },
      }
    );
    engineRef.current = engine;
    return () => {
      engine.destroy();
      engineRef.current = null;
    };
    // The match is intentionally mounted once per fixture.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [restartKey]);

  useEffect(() => {
    setSoundEnabled(sound);
  }, [sound]);

  const move = useCallback((x: number, y: number) => {
    engineRef.current?.setMove(x, y);
  }, []);

  const shoot = useCallback(() => {
    unlockAudio();
    engineRef.current?.shoot();
  }, []);

  const useSignature = useCallback(() => {
    unlockAudio();
    engineRef.current?.useSkill();
  }, []);

  useEffect(() => {
    const keys = new Set<string>();
    const sync = () => {
      const x = (keys.has("d") || keys.has("arrowright") ? 1 : 0) - (keys.has("a") || keys.has("arrowleft") ? 1 : 0);
      const y = (keys.has("s") || keys.has("arrowdown") ? 1 : 0) - (keys.has("w") || keys.has("arrowup") ? 1 : 0);
      engineRef.current?.setMove(x, y);
    };
    const onKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " ", "spacebar"].includes(key)) e.preventDefault();
      if (key === " " || key === "spacebar") {
        if (!keys.has("space")) shoot();
        keys.add("space");
        return;
      }
      if (key === "shift") {
        if (!keys.has("shift")) useSignature();
        keys.add("shift");
        return;
      }
      if (key === "p" || key === "escape") {
        e.preventDefault();
        engineRef.current?.togglePause();
        return;
      }
      if (key === "r" && e.shiftKey) {
        engineRef.current?.restart();
        setOutcome(null);
        setHud((h) => ({ ...h, status: "countdown" }));
        return;
      }
      keys.add(key);
      sync();
    };
    const onKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      keys.delete(key === " " ? "space" : key);
      sync();
    };
    const onBlur = () => {
      keys.clear();
      engineRef.current?.setMove(0, 0);
      engineRef.current?.pause();
    };
    window.addEventListener("keydown", onKeyDown, { passive: false });
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    document.addEventListener("visibilitychange", onBlur);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
      document.removeEventListener("visibilitychange", onBlur);
    };
  }, [shoot, useSignature]);

  const togglePause = () => {
    unlockAudio();
    engineRef.current?.togglePause();
  };

  const restart = () => {
    setOutcome(null);
    setRestartKey((k) => k + 1);
    playSound("ui");
  };

  const toneColor =
    hud.announcement?.tone === "goal"
      ? "border-volt/60 bg-volt text-ink"
      : hud.announcement?.tone === "skill"
        ? "border-sky/50 bg-sky/15 text-sky"
        : hud.announcement?.tone === "tackle"
          ? "border-coral/50 bg-coral/15 text-coral"
          : hud.announcement?.tone === "save"
            ? "border-gold/50 bg-gold/15 text-gold"
            : "border-line bg-ink-2/95 text-cream";

  const effect = effectFor(signature.effect);
  const celebration = celebrationFor(signature.celebration);
  const timeLow = hud.timeLeft <= 10;

  return (
    <div className="fixed inset-0 z-[70] flex flex-col overflow-hidden bg-[#070a07] text-cream">
      {/* Scorebar */}
      <header className="game-scorebar relative z-20 flex h-[58px] shrink-0 items-center justify-between gap-2 border-b border-white/10 bg-[#0a0e0a] px-2 sm:h-[66px] sm:px-4">
        <div className="flex min-w-0 items-center gap-2">
          <button
            onClick={onExit}
            className="grid size-9 shrink-0 place-items-center rounded-full border border-line text-muted transition hover:border-cream/40 hover:text-cream"
            aria-label="Leave match"
          >
            <Icon name="close" size={17} />
          </button>
          <div className="score-team hidden min-w-0 sm:block">
            <p className="truncate text-[9px] font-extrabold uppercase tracking-[0.22em] text-muted">
              {division.name} · vs {division.rival}
            </p>
            <p className="truncate font-display text-[15px] leading-tight">{division.location}</p>
          </div>
          <div className="sm:hidden">
            <p className="text-[8px] font-extrabold uppercase tracking-[0.2em] text-muted">{division.short}</p>
            <p className="font-display text-[12px] leading-tight">
              Goals <span className="text-volt">{hud.goals}</span>/{division.target}
            </p>
          </div>
        </div>

        <div className="absolute left-1/2 flex -translate-x-1/2 items-end gap-2 sm:gap-4">
          <div className="text-right">
            <p className="text-[8px] font-extrabold uppercase tracking-[0.22em] text-volt">Score</p>
            <p className="font-display text-[22px] leading-none tracking-wide sm:text-[30px]">{formatNumber(hud.score)}</p>
          </div>
          <div className="h-8 w-px bg-white/10" />
          <div>
            <p className={`text-[8px] font-extrabold uppercase tracking-[0.22em] ${timeLow ? "text-coral" : "text-muted"}`}>
              {hud.timeLeft === 0 ? "Full time" : "Time"}
            </p>
            <p className={`font-display text-[22px] leading-none tabular-nums sm:text-[30px] ${timeLow ? "animate-blink text-coral" : ""}`}>
              {formatClock(hud.timeLeft)}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-3">
          <div className="hidden items-center gap-1.5 md:flex">
            {Array.from({ length: division.target }).map((_, i) => (
              <span
                key={i}
                className={`h-2 w-5 rounded-full transition ${i < hud.goals ? "bg-volt shadow-[0_0_10px_rgba(216,255,62,0.55)]" : "bg-white/12"}`}
              />
            ))}
          </div>
          <div className="hidden text-right sm:block">
            <p className="text-[8px] font-extrabold uppercase tracking-[0.2em] text-muted">Goals</p>
            <p className="font-display text-[16px] leading-tight">
              <span className="text-volt">{hud.goals}</span>
              <span className="text-muted">/{division.target}</span>
            </p>
          </div>
          <button
            onClick={togglePause}
            className="grid size-9 place-items-center rounded-full border border-line bg-ink-3 text-cream transition hover:border-volt/60 hover:text-volt"
            aria-label={hud.status === "paused" ? "Resume match" : "Pause match"}
          >
            <Icon name={hud.status === "paused" ? "play" : "pause"} size={16} />
          </button>
          <button
            onClick={() => {
              onToggleSound();
              playSound("ui");
            }}
            className="hidden size-9 place-items-center rounded-full border border-line bg-ink-3 text-muted transition hover:text-cream sm:grid"
            aria-label={sound ? "Mute sound" : "Enable sound"}
          >
            <Icon name={sound ? "sound" : "mute"} size={16} />
          </button>
        </div>
      </header>

      {/* Pitch */}
      <div className="relative flex min-h-0 flex-1 flex-col">
        <div className="relative min-h-0 flex-1">
          <canvas
            ref={canvasRef}
            onPointerDown={(e) => {
              if (e.pointerType === "touch" && hud.status === "playing") shoot();
            }}
            onContextMenu={(e) => e.preventDefault()}
            className="absolute inset-0 h-full w-full touch-none [image-rendering:auto]"
            aria-label="Street football pitch"
            role="application"
          />

          {/* Combo / style HUD */}
          <div className="pointer-events-none absolute left-2 top-2 flex flex-col items-start gap-2 sm:left-4 sm:top-4">
            <div className="flex items-center overflow-hidden rounded-xl border border-white/10 bg-ink/80 backdrop-blur-md">
              <div className="px-2.5 py-1.5 sm:px-3">
                <p className="text-[8px] font-extrabold uppercase tracking-[0.2em] text-muted">Style</p>
                <p className="font-display text-[17px] leading-none">
                  <span className={hud.combo > 0 ? "text-volt" : "text-cream"}>{hud.combo}x</span>
                  <span className="ml-1 text-[11px] text-muted">COMBO</span>
                </p>
              </div>
              <div className="border-l border-white/10 bg-white/[0.04] px-2.5 py-1.5 sm:px-3">
                <p className="text-[8px] font-extrabold uppercase tracking-[0.2em] text-muted">Multi</p>
                <p className="font-display text-[17px] leading-none text-gold">×{hud.multiplier}</p>
              </div>
            </div>
            {hud.signatureUses > 0 && (
              <div className="hidden rounded-full border border-white/10 bg-ink/70 px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.16em] text-muted backdrop-blur sm:block">
                Signature used {hud.signatureUses}×
              </div>
            )}
          </div>

          {/* Signature meter */}
          <div className="pointer-events-none absolute right-2 top-2 w-[132px] rounded-xl border border-white/10 bg-ink/80 p-2 backdrop-blur-md sm:right-4 sm:top-4 sm:w-[168px] sm:p-2.5">
            <div className="flex items-center justify-between gap-2">
              <span className="flex min-w-0 items-center gap-1 text-[8px] font-extrabold uppercase tracking-[0.16em] text-muted">
                <span>{effect.icon}</span>
                <span className="truncate">Signature</span>
              </span>
              <span
                className={`shrink-0 rounded-full px-1.5 py-0.5 text-[8px] font-extrabold uppercase tracking-[0.1em] ${
                  hud.skillReady ? "bg-volt text-ink" : "bg-white/10 text-muted"
                }`}
              >
                {hud.skillReady ? "Ready" : `${hud.skill}%`}
              </span>
            </div>
            <p className="mt-0.5 truncate font-display text-[13px] leading-tight text-cream">{signature.name}</p>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full transition-[width] duration-150"
                style={{
                  width: `${hud.skill}%`,
                  background: `linear-gradient(90deg, ${signature.color}88, ${signature.color})`,
                  boxShadow: hud.skillReady ? `0 0 12px ${signature.color}` : "none",
                }}
              />
            </div>
          </div>

          {/* Announcement toast */}
          {hud.announcement && !outcome && (
            <div
              key={hud.announcement.id}
              className={`animate-pop pointer-events-none absolute left-1/2 top-[calc(50%-86px)] z-10 w-max max-w-[86%] -translate-x-1/2 rounded-xl border px-3 py-1.5 text-center shadow-xl sm:top-[44%] ${toneColor}`}
              role="status"
              aria-live="polite"
            >
              <p className="font-display text-[15px] leading-tight tracking-wide sm:text-[18px]">{hud.announcement.label}</p>
              <p className="text-[9px] font-bold uppercase tracking-[0.12em] opacity-70">{hud.announcement.detail}</p>
            </div>
          )}

          {hud.celebration && !outcome && (
            <div className="pointer-events-none absolute inset-x-0 bottom-3 flex justify-center">
              <div className="animate-pop flex items-center gap-2 rounded-full border border-white/15 bg-ink/85 px-3 py-1.5 backdrop-blur-md">
                <span className="text-lg">{hud.celebration.emoji}</span>
                <span className="text-[9px] font-extrabold uppercase tracking-[0.18em] text-muted">Signature celebration</span>
                <span className="font-display text-[13px] uppercase" style={{ color: hud.celebration.color }}>
                  {hud.celebration.name}
                </span>
              </div>
            </div>
          )}

          {/* Pause overlay */}
          {hud.status === "paused" && !outcome && (
            <div className="absolute inset-0 z-20 grid place-items-center bg-[#050805]/80 p-4 backdrop-blur-sm">
              <div className="animate-pop w-full max-w-sm rounded-2xl border border-line bg-ink-2 p-5 shadow-2xl">
                <div className="flex items-center justify-between">
                  <span className="rounded-full border border-volt/30 bg-volt/10 px-2 py-1 text-[9px] font-extrabold uppercase tracking-[0.22em] text-volt">
                    Match paused
                  </span>
                  <span className="font-display text-[13px] text-muted">{division.short}</span>
                </div>
                <h2 className="mt-3 font-display text-5xl leading-none">Take a breath.</h2>
                <div className="mt-4 grid grid-cols-3 gap-2">
                  {[
                    ["Score", formatNumber(hud.score)],
                    ["Goals", `${hud.goals}/${division.target}`],
                    ["Time", formatClock(hud.timeLeft)],
                  ].map(([label, value]) => (
                    <div key={label} className="rounded-xl border border-white/8 bg-black/20 p-2 text-center">
                      <p className="text-[8px] font-extrabold uppercase tracking-[0.16em] text-muted">{label}</p>
                      <p className="font-display text-lg">{value}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-4 grid gap-2 text-[10px] font-semibold text-muted">
                  <p className="flex items-center gap-2">
                    <span className="rounded border border-line px-1.5 py-0.5 text-[9px] text-cream">WASD</span> Move around the cage
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="rounded border border-line px-1.5 py-0.5 text-[9px] text-cream">SPACE</span> Shoot at the open corner
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="rounded border border-line px-1.5 py-0.5 text-[9px] text-cream">SHIFT</span> Deploy your signature move
                  </p>
                </div>
                <div className="mt-5 space-y-2">
                  <button
                    onClick={() => engineRef.current?.resume()}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-volt py-3 font-display text-[18px] tracking-wide text-ink transition hover:bg-volt-dim"
                  >
                    <Icon name="play" size={16} /> Resume match
                  </button>
                  <button
                    onClick={onToggleSound}
                    className="flex w-full items-center justify-between rounded-xl border border-line bg-white/[0.03] px-3 py-2 text-[10px] font-extrabold uppercase tracking-[0.14em] text-muted transition hover:text-cream"
                  >
                    <span className="flex items-center gap-2">
                      <Icon name={sound ? "sound" : "mute"} size={14} /> Sound {sound ? "on" : "off"}
                    </span>
                    <span className="rounded border border-line px-1.5 py-0.5 text-[8px]">{sound ? "Tap to mute" : "Tap for audio"}</span>
                  </button>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={restart}
                      className="flex items-center justify-center gap-2 rounded-xl border border-line bg-ink-3 py-2.5 text-[11px] font-extrabold uppercase tracking-[0.12em] text-cream transition hover:border-volt/50"
                    >
                      <Icon name="refresh" size={14} /> Restart
                    </button>
                    <button
                      onClick={onExit}
                      className="flex items-center justify-center gap-2 rounded-xl border border-line bg-ink-3 py-2.5 text-[11px] font-extrabold uppercase tracking-[0.12em] text-muted transition hover:text-cream"
                    >
                      <Icon name="home" size={14} /> Hub
                    </button>
                  </div>
                </div>
                <p className="mt-3 text-center text-[9px] uppercase tracking-[0.16em] text-muted/70">
                  Audio {sound ? "on" : "off"} · press P to resume
                </p>
              </div>
            </div>
          )}

          {/* Full time overlay */}
          {outcome && (
            <div className="absolute inset-0 z-30 overflow-y-auto bg-[#050805]/88 p-3 backdrop-blur-md sm:p-6">
              {outcome.result.won && (
                <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
                  {Array.from({ length: 18 }).map((_, i) => (
                    <span
                      key={i}
                      className="absolute top-0 block rounded-[1px]"
                      style={{
                        left: `${(i * 5.6 + 3) % 100}%`,
                        width: i % 3 === 0 ? 7 : 4,
                        height: i % 3 === 0 ? 14 : 8,
                        background: ["#d8ff3e", "#ffce4f", "#f3f1e6", "#ff6b4a", "#7dd3fc"][i % 5],
                        animation: `confetti-fall ${2.4 + (i % 5) * 0.32}s linear ${(i % 7) * 0.16}s infinite`,
                        ["--drift" as string]: `${((i % 6) - 3) * 26}px`,
                      } as React.CSSProperties}
                    />
                  ))}
                </div>
              )}
              <div className="mx-auto grid max-h-full w-full max-w-3xl animate-pop overflow-hidden rounded-2xl border border-line bg-ink-2 shadow-2xl md:grid-cols-[1.08fr_0.92fr]">
                <div className="relative overflow-hidden p-5 sm:p-6">
                  <div
                    className="pointer-events-none absolute -right-20 -top-24 size-64 rounded-full opacity-25 blur-3xl"
                    style={{ background: outcome.result.won ? division.accent : "#ff6b4a" }}
                  />
                  <div className="relative flex items-center justify-between">
                    <span className="rounded-full border border-white/15 bg-white/5 px-2 py-1 text-[9px] font-extrabold uppercase tracking-[0.22em] text-muted">
                      Full time · {outcome.result.won ? "Victory" : "Game over"}
                    </span>
                    {outcome.reward.personalBest && (
                      <span className="rounded-full bg-gold/15 px-2 py-1 text-[9px] font-extrabold uppercase tracking-[0.16em] text-gold">
                        New personal best
                      </span>
                    )}
                  </div>
                  <h2 className="relative mt-3 font-display text-4xl leading-[0.92] sm:text-6xl">
                    {outcome.result.won ? (
                      <>
                        YOU RAN
                        <br />
                        <span style={{ color: division.accent }}>THE BLOCK.</span>
                      </>
                    ) : (
                      <>
                        NOT ENOUGH
                        <br />
                        <span className="text-coral">THIS TIME.</span>
                      </>
                    )}
                  </h2>
                  <p className="relative mt-2 max-w-[36ch] text-[11px] leading-relaxed text-muted">
                    {outcome.result.won
                      ? `${division.rival} had no answer. The ${division.location.split("·")[0].trim()} belongs to you.`
                      : `${division.target - outcome.result.goals} more goal${division.target - outcome.result.goals === 1 ? "" : "s"} needed. The block remembers. Run it back.`}
                  </p>

                  <div className="relative mt-4 rounded-xl border border-white/10 bg-black/25 p-4">
                    <div className="flex items-end justify-between gap-3">
                      <div>
                        <p className="text-[9px] font-extrabold uppercase tracking-[0.24em] text-muted">Final score</p>
                        <p className="font-display text-[48px] leading-none tracking-wide sm:text-[58px]">
                          {formatNumber(outcome.result.score)}
                        </p>
                      </div>
                      <div className="mb-1 text-right">
                        <p className="text-[9px] font-extrabold uppercase tracking-[0.2em] text-muted">Goals</p>
                        <p className="font-display text-2xl leading-none">
                          <span className="text-volt">{outcome.result.goals}</span>
                          <span className="text-muted">/{outcome.result.target}</span>
                        </p>
                      </div>
                    </div>
                    <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                      {[
                        ["Best combo", `${outcome.result.bestCombo}x`],
                        ["Signature", `${outcome.result.signatureUses}×`],
                        ["Time left", formatClock(outcome.result.timeLeft)],
                      ].map(([label, value]) => (
                        <div key={label} className="rounded-lg border border-white/8 bg-white/[0.03] px-1 py-1.5">
                          <p className="text-[7px] font-extrabold uppercase tracking-[0.14em] text-muted">{label}</p>
                          <p className="font-display text-[15px]">{value}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="relative mt-3 flex flex-wrap gap-2">
                    <span className="flex items-center gap-1.5 rounded-full border border-gold/25 bg-gold/10 px-2.5 py-1.5 text-[11px] font-extrabold text-gold">
                      <Icon name="coin" size={13} /> +{outcome.reward.coins} coins
                    </span>
                    <span className="flex items-center gap-1.5 rounded-full border border-sky/25 bg-sky/10 px-2.5 py-1.5 text-[11px] font-extrabold text-sky">
                      <Icon name="bolt" size={13} /> +{outcome.reward.xp} XP
                    </span>
                    {outcome.reward.trophy && (
                      <span className="flex items-center gap-1.5 rounded-full border border-volt/30 bg-volt/10 px-2.5 py-1.5 text-[11px] font-extrabold text-volt">
                        <Icon name="trophy" size={13} /> {outcome.reward.trophy}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-col justify-between gap-4 border-t border-line bg-[#0c110c] p-5 md:border-l md:border-t-0 sm:p-6">
                  <div>
                    <div className="flex items-center justify-between">
                      <p className="text-[9px] font-extrabold uppercase tracking-[0.22em] text-muted">Your signature</p>
                      <span className="font-display text-[11px] text-volt">
                        {outcome.reward.rank > 0 ? `#${outcome.reward.rank} locally` : "Beyond the board"}
                      </span>
                    </div>
                    <div className="mt-2 flex items-center gap-3 rounded-xl border border-white/10 bg-black/30 p-3">
                      <span
                        className="grid size-10 place-items-center rounded-full text-lg"
                        style={{ background: `${signature.color}1a`, border: `1px solid ${signature.color}55` }}
                      >
                        {effect.icon}
                      </span>
                      <div className="min-w-0">
                        <p className="truncate font-display text-lg uppercase leading-tight">{signature.name}</p>
                        <p className="truncate text-[10px] text-muted">
                          {celebration.emoji} {signature.celebrationName}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <p className="mb-2 text-[9px] font-extrabold uppercase tracking-[0.22em] text-muted">Local leaderboard</p>
                    <div className="space-y-1">
                      {scores.slice(0, 4).map((entry, i) => (
                        <div
                          key={entry.id}
                          className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-[11px] ${
                            entry.name === profile.name && !entry.ghost ? "bg-volt/10 text-cream" : "text-muted"
                          }`}
                        >
                          <span className="w-4 font-display text-xs text-muted">{i + 1}</span>
                          <span className="min-w-0 flex-1 truncate font-bold uppercase tracking-wide">{entry.name}</span>
                          <span className="font-display text-[13px] text-cream">{formatNumber(entry.score)}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <button
                      onClick={() => {
                        restart();
                        unlockAudio();
                      }}
                      className="group flex w-full items-center justify-between gap-3 rounded-xl bg-volt px-4 py-3 font-display text-[19px] tracking-wide text-ink transition hover:bg-volt-dim active:scale-[0.99]"
                    >
                      <span className="flex items-center gap-2">
                        <Icon name="refresh" size={17} /> Run it back
                      </span>
                      <Icon name="arrow" size={17} className="transition group-hover:translate-x-0.5" />
                    </button>
                    <button
                      onClick={onExit}
                      className="flex w-full items-center justify-center gap-2 rounded-xl border border-line bg-white/[0.03] py-2.5 text-[10px] font-extrabold uppercase tracking-[0.16em] text-muted transition hover:border-cream/30 hover:text-cream"
                    >
                      <Icon name="home" size={13} /> Back to the block
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="game-controls relative z-20 flex shrink-0 items-center justify-between gap-2 border-t border-white/10 bg-[#0a0e0a] px-3 pb-[max(10px,env(safe-area-inset-bottom))] pt-2 sm:px-5 sm:py-3">
          <Joystick onMove={move} />
          <div className="keyboard-hints hidden flex-1 flex-col items-center justify-center gap-1 md:flex">
            <div className="flex items-center gap-3 text-[9px] font-bold uppercase tracking-[0.12em] text-muted">
              <span className="flex items-center gap-1">
                <kbd className="rounded border border-line bg-ink-3 px-1.5 py-0.5 text-cream">WASD</kbd> move
              </span>
              <span className="flex items-center gap-1">
                <kbd className="rounded border border-line bg-ink-3 px-1.5 py-0.5 text-cream">SPACE</kbd> shoot
              </span>
              <span className="flex items-center gap-1">
                <kbd className="rounded border border-line bg-ink-3 px-1.5 py-0.5 text-cream">SHIFT</kbd> signature
              </span>
              <span className="flex items-center gap-1">
                <kbd className="rounded border border-line bg-ink-3 px-1.5 py-0.5 text-cream">P</kbd> pause
              </span>
            </div>
            <p className="text-[9px] text-muted/60">
              {teammate ? `${teammate.name} · ${teammate.boostLabel}` : "No teammate equipped"} · Tap the pitch to shoot
            </p>
          </div>
          <div className="flex items-center gap-2.5 sm:gap-3">
            <button
              onClick={useSignature}
              disabled={!hud.skillReady}
              aria-label={`Use signature move ${signature.name}`}
              className="action-skill group relative grid size-[62px] shrink-0 place-items-center rounded-full border-2 transition active:scale-95 disabled:opacity-45 sm:size-[68px]"
              style={{
                borderColor: hud.skillReady ? signature.color : "#2a3027",
                background: hud.skillReady ? `${signature.color}1f` : "#171c15",
                boxShadow: hud.skillReady ? `0 0 24px -4px ${signature.color}aa` : "none",
              }}
            >
              <span className="text-xl">{effect.icon}</span>
              <span className="absolute -bottom-1 rounded-full bg-ink px-1.5 text-[7px] font-extrabold uppercase tracking-[0.1em] text-muted">
                {hud.skillReady ? "Signature" : `${hud.skill}%`}
              </span>
            </button>
            <button
              onClick={shoot}
              aria-label="Shoot"
              className="action-primary grid size-[76px] shrink-0 place-items-center rounded-full border-2 border-ink bg-volt text-ink shadow-[0_0_30px_-6px_rgba(216,255,62,0.7)] transition hover:bg-volt-dim active:scale-95 sm:size-[84px]"
            >
              <Icon name="ball" size={28} strokeWidth={2} />
              <span className="mt-0.5 font-display text-[10px] uppercase tracking-widest">Shoot</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function formatClock(totalSeconds: number): string {
  const safe = Math.max(0, Math.ceil(totalSeconds));
  const minutes = Math.floor(safe / 60);
  const seconds = safe % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function Joystick({ onMove }: { onMove: (x: number, y: number) => void }) {
  // pointer capture keeps the thumb drag alive outside the joystick base
  const baseRef = useRef<HTMLDivElement | null>(null);
  const knobRef = useRef<HTMLDivElement | null>(null);
  const pointer = useRef<number | null>(null);
  const [active, setActive] = useState(false);

  const setKnob = (x: number, y: number) => {
    if (knobRef.current) knobRef.current.style.transform = `translate3d(${x}px, ${y}px, 0)`;
  };

  const handle = (clientX: number, clientY: number) => {
    const base = baseRef.current;
    if (!base) return;
    const rect = base.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const max = rect.width * 0.31;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > max) {
      dx = (dx / dist) * max;
      dy = (dy / dist) * max;
    }
    setKnob(dx, dy);
    onMove(dx / max, dy / max);
  };

  const reset = () => {
    pointer.current = null;
    setKnob(0, 0);
    setActive(false);
    onMove(0, 0);
  };

  return (
    <div className="flex items-center gap-2">
      <div
        ref={baseRef}
        onPointerDown={(e) => {
          e.preventDefault();
          pointer.current = e.pointerId;
          e.currentTarget.setPointerCapture(e.pointerId);
          setActive(true);
          handle(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (pointer.current !== e.pointerId) return;
          handle(e.clientX, e.clientY);
        }}
        onPointerUp={(e) => {
          if (pointer.current === e.pointerId) reset();
        }}
        onPointerCancel={reset}
        onPointerLeave={(e) => {
          if (pointer.current === e.pointerId && e.buttons === 0) reset();
        }}
        className={`joystick-base relative grid size-[104px] touch-none select-none place-items-center rounded-full border transition sm:size-[112px] ${
          active ? "border-volt/70 bg-volt/[0.08]" : "border-line bg-white/[0.035]"
        }`}
        aria-label="Movement joystick"
        role="button"
        tabIndex={0}
      >
        <span className="absolute inset-3 rounded-full border border-white/10" />
        <span className="absolute left-1/2 top-2.5 h-0 w-0 -translate-x-1/2 border-x-4 border-b-[6px] border-x-transparent border-b-muted/50" />
        <span className="absolute bottom-2.5 left-1/2 h-0 w-0 -translate-x-1/2 border-x-4 border-t-[6px] border-x-transparent border-t-muted/50" />
        <span className="absolute left-2.5 top-1/2 h-0 w-0 -translate-y-1/2 border-y-4 border-r-[6px] border-y-transparent border-r-muted/50" />
        <span className="absolute right-2.5 top-1/2 h-0 w-0 -translate-y-1/2 border-y-4 border-l-[6px] border-y-transparent border-l-muted/50" />
        <div
          ref={knobRef}
          className={`relative grid size-12 place-items-center rounded-full border-2 transition-[background,border] ${
            active ? "border-volt bg-volt text-ink" : "border-white/20 bg-ink-3 text-muted"
          }`}
        >
          <span className="flex flex-col items-center gap-0.5">
            <Icon name="hand" size={15} />
          </span>
        </div>
      </div>
      <div className="joystick-label hidden flex-col text-[8px] font-extrabold uppercase leading-relaxed tracking-[0.14em] text-muted/70 sm:flex">
        <span>Drag</span>
        <span>to move</span>
      </div>
    </div>
  );
}


