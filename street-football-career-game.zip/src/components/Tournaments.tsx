import { DIVISIONS, divisionUnlocked, levelForXp, nextFixture, type Division, type Profile } from "../lib/data";
import { Icon } from "./Icons";

interface TournamentProps {
  profile: Profile;
  onEnter: (division: Division) => void;
}

export function Tournaments({ profile, onEnter }: TournamentProps) {
  const level = levelForXp(profile.xp);
  const next = nextFixture(profile);

  return (
    <div>
      <div className="relative overflow-hidden rounded-2xl border border-line bg-[#0b120c] p-4 sm:p-5">
        <div className="pitch-grid absolute inset-0 opacity-40" />
        <div className="absolute -right-10 -top-16 size-56 rounded-full bg-volt/10 blur-3xl" />
        <div className="relative flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[9px] font-extrabold uppercase tracking-[0.24em] text-volt">Your next fixture</p>
            <h3 className="mt-1 font-display text-3xl leading-none sm:text-4xl">{next.name}</h3>
            <p className="mt-1 text-[11px] text-muted">
              {next.location} · {next.rival}
            </p>
          </div>
          <button
            onClick={() => onEnter(next)}
            className="flex items-center gap-2 rounded-xl bg-volt px-4 py-2.5 font-display text-lg tracking-wide text-ink transition hover:bg-volt-dim active:scale-[0.98]"
          >
            Play match <Icon name="arrow" size={16} />
          </button>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <div className="rounded-xl border border-line bg-black/20 px-3 py-2">
          <p className="text-[8px] font-extrabold uppercase tracking-[0.18em] text-muted">Trophies</p>
          <p className="font-display text-2xl leading-tight">
            {profile.trophies.length} <span className="text-sm text-muted">/ {DIVISIONS.length}</span>
          </p>
        </div>
        <div className="rounded-xl border border-line bg-black/20 px-3 py-2">
          <p className="text-[8px] font-extrabold uppercase tracking-[0.18em] text-muted">Rank level</p>
          <p className="font-display text-2xl leading-tight">
            {level} <span className="text-sm text-muted">street</span>
          </p>
        </div>
      </div>

      <div className="mt-5 space-y-2.5">
        {DIVISIONS.map((division, index) => {
          const unlocked = divisionUnlocked(division, profile);
          const won = profile.trophies.includes(division.id);
          const current = next.id === division.id;
          return (
            <article
              key={division.id}
              className={`relative overflow-hidden rounded-2xl border p-3.5 sm:p-4 ${
                current && unlocked ? "border-volt/50 bg-volt/[0.05]" : "border-line bg-black/20"
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className="relative grid size-11 shrink-0 place-items-center rounded-xl border font-display text-lg"
                  style={{
                    borderColor: unlocked ? `${division.accent}55` : "#2a3027",
                    background: unlocked ? `${division.accent}14` : "#121610",
                    color: unlocked ? division.accent : "#6e776a",
                  }}
                >
                  {won ? <Icon name="trophy" size={21} /> : unlocked ? `0${index + 1}` : <Icon name="lock" size={17} />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                    <p className={`font-display text-lg leading-tight ${unlocked ? "text-cream" : "text-muted"}`}>
                      {division.name}
                    </p>
                    {won && (
                      <span className="rounded-full bg-volt/15 px-1.5 py-0.5 text-[7px] font-extrabold uppercase tracking-[0.1em] text-volt">
                        Won
                      </span>
                    )}
                    {current && !won && (
                      <span className="rounded-full bg-sky/15 px-1.5 py-0.5 text-[7px] font-extrabold uppercase tracking-[0.1em] text-sky">
                        Next up
                      </span>
                    )}
                  </div>
                  <p className="truncate text-[10px] text-muted">
                    {division.tagline} · {division.target} goals · {division.duration}s
                  </p>
                </div>
                {unlocked ? (
                  <button
                    onClick={() => onEnter(division)}
                    className="shrink-0 rounded-full border border-volt/40 bg-volt/10 px-3 py-1.5 text-[9px] font-extrabold uppercase tracking-[0.12em] text-volt transition hover:bg-volt hover:text-ink"
                  >
                    Enter
                  </button>
                ) : (
                  <div className="shrink-0 text-right">
                    <p className="text-[8px] font-extrabold uppercase tracking-[0.12em] text-muted">Level {division.unlockLevel}</p>
                    <p className="text-[9px] text-muted/60">{division.unlockLevel - level} to go</p>
                  </div>
                )}
              </div>
              {unlocked && <div className="mt-3 h-px bg-white/5" />}
              {unlocked && (
                <div className="mt-2 flex items-center justify-between text-[9px] font-bold uppercase tracking-[0.08em] text-muted/70">
                  <span>
                    Reward {division.reward} coins · {division.xp} XP
                  </span>
                  <span>{division.trophy}</span>
                </div>
              )}
            </article>
          );
        })}
      </div>
      <p className="mt-3 text-center text-[9px] uppercase tracking-[0.14em] text-muted/60">
        Win fixtures to earn XP, unlock higher levels and lift every trophy.
      </p>
    </div>
  );
}
