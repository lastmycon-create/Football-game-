import { useState } from "react";
import {
  CELEBRATIONS,
  SIGNATURE_COLORS,
  SKILL_EFFECTS,
  celebrationFor,
  effectFor,
  type CelebrationId,
  type Profile,
  type Signature,
  type SkillEffectId,
} from "../lib/data";
import { Icon } from "./Icons";

interface StudioProps {
  profile: Profile;
  onClose: () => void;
  onSave: (signature: Signature, playerName: string) => void;
  onStart: (signature: Signature, playerName: string) => void;
}

const PREFIXES = ["Lime", "Neon", "Ghost", "Velvet", "Midnight", "Concrete", "Solar", "Rogue", "Electric", "Golden"];
const NOUNS = ["Wormhole", "Silk", "Volt", "Afterglow", "Heel", "Dance", "Mirage", "Riot", "Flick", "Orbit"];
const CELEB_WORDS = ["Slide", "Shuffle", "Signal", "Freeze", "Salute", "Ritual", "Bounce", "Pose"];

const PRESETS: { label: string; signature: Signature }[] = [
  {
    label: "Wormhole",
    signature: {
      name: "The Wormhole",
      effect: "dash",
      color: "#d8ff3e",
      celebration: "moonwalk",
      celebrationName: "The Lime Slide",
    },
  },
  {
    label: "Ice Cold",
    signature: { name: "Absolute Zero", effect: "freeze", color: "#7dd3fc", celebration: "robot", celebrationName: "System Glitch" },
  },
  {
    label: "Golden Heel",
    signature: { name: "The Golden Heel", effect: "rocket", color: "#ffce4f", celebration: "goat", celebrationName: "Crown The Kid" },
  },
];

export function Studio({ profile, onClose, onSave, onStart }: StudioProps) {
  const [draft, setDraft] = useState<Signature>({ ...profile.signature });
  const [playerName, setPlayerName] = useState(profile.name);
  const [pulse, setPulse] = useState(0);
  const [saved, setSaved] = useState(false);

  const valid = draft.name.trim().length > 1 && draft.celebrationName.trim().length > 1 && playerName.trim().length > 0;
  const effect = effectFor(draft.effect);
  const celebration = celebrationFor(draft.celebration);

  const patch = (next: Partial<Signature>) => {
    setDraft((d) => ({ ...d, ...next }));
    setSaved(false);
  };

  const save = () => {
    if (!valid) return;
    onSave({ ...draft, name: draft.name.trim(), celebrationName: draft.celebrationName.trim() }, playerName.trim().toUpperCase());
    setSaved(true);
    setPulse((p) => p + 1);
  };

  const test = () => {
    if (!valid) return;
    onStart({ ...draft, name: draft.name.trim(), celebrationName: draft.celebrationName.trim() }, playerName.trim().toUpperCase());
  };

  const randomise = () => {
    const color = SIGNATURE_COLORS[Math.floor(Math.random() * SIGNATURE_COLORS.length)];
    const skill = SKILL_EFFECTS[Math.floor(Math.random() * SKILL_EFFECTS.length)];
    const move = CELEBRATIONS[Math.floor(Math.random() * CELEBRATIONS.length)];
    setDraft({
      name: `The ${PREFIXES[Math.floor(Math.random() * PREFIXES.length)]} ${NOUNS[Math.floor(Math.random() * NOUNS.length)]}`,
      effect: skill.id,
      color,
      celebration: move.id,
      celebrationName: `${PREFIXES[Math.floor(Math.random() * PREFIXES.length)]} ${CELEB_WORDS[Math.floor(Math.random() * CELEB_WORDS.length)]}`,
    });
    setSaved(false);
    setPulse((p) => p + 1);
  };

  return (
    <div className="grid gap-5 lg:grid-cols-[1.06fr_0.94fr]">
      <div className="min-w-0 space-y-5">
        <div className="grid gap-3 sm:grid-cols-[0.7fr_1.3fr]">
          <label className="block">
            <span className="mb-1.5 flex items-center justify-between text-[9px] font-extrabold uppercase tracking-[0.18em] text-muted">
              Player tag <span>{playerName.length}/12</span>
            </span>
            <input
              value={playerName}
              maxLength={12}
              onChange={(e) => {
                setPlayerName(e.target.value.toUpperCase().replace(/[^A-Z0-9· -]/g, ""));
                setSaved(false);
              }}
              className="w-full rounded-xl border border-line bg-black/30 px-3 py-2.5 font-display text-lg uppercase tracking-wider text-cream outline-none transition placeholder:text-muted/40 focus:border-volt/60"
              placeholder="YOUR TAG"
            />
          </label>
          <label className="block">
            <span className="mb-1.5 flex items-center justify-between text-[9px] font-extrabold uppercase tracking-[0.18em] text-muted">
              Signature move <span>{draft.name.length}/24</span>
            </span>
            <div className="relative">
              <input
                value={draft.name}
                maxLength={24}
                onChange={(e) => patch({ name: e.target.value })}
                className="w-full rounded-xl border border-line bg-black/30 py-2.5 pl-3 pr-10 font-display text-lg tracking-wide text-cream outline-none transition placeholder:text-muted/40 focus:border-volt/60"
                placeholder="NAME YOUR MOVE"
              />
              <button
                onClick={randomise}
                type="button"
                className="absolute right-1.5 top-1/2 grid size-7 -translate-y-1/2 place-items-center rounded-lg border border-line text-muted transition hover:border-volt/50 hover:text-volt"
                aria-label="Surprise me"
                title="Surprise me"
              >
                <Icon name="spark" size={14} />
              </button>
            </div>
          </label>
        </div>

        <div>
          <div className="mb-2 flex items-center gap-2">
            <span className="grid size-5 place-items-center rounded-md bg-volt/15 text-[9px] font-extrabold text-volt">01</span>
            <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-cream">Choose your power</p>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {SKILL_EFFECTS.map((item) => {
              const selected = draft.effect === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    patch({ effect: item.id as SkillEffectId });
                    setPulse((p) => p + 1);
                  }}
                  className="rounded-xl border p-3 text-left transition"
                  style={{
                    borderColor: selected ? `${draft.color}99` : "#2a3027",
                    background: selected ? `${draft.color}12` : "rgba(0,0,0,0.2)",
                  }}
                  aria-pressed={selected}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">{item.icon}</span>
                    <span
                      className="text-[7px] font-extrabold uppercase tracking-[0.14em]"
                      style={{ color: selected ? draft.color : "#7b8477" }}
                    >
                      {item.tag}
                    </span>
                  </div>
                  <p className="mt-1.5 font-display text-[15px] uppercase leading-tight">{item.name}</p>
                  <p className="mt-0.5 text-[9px] leading-snug text-muted">{item.short}</p>
                </button>
              );
            })}
          </div>
          <p className="mt-1.5 rounded-lg bg-black/20 px-2.5 py-2 text-[10px] leading-relaxed text-muted">
            <span className="text-cream">{effect.icon} In the match:</span> {effect.description}
          </p>
        </div>

        <div>
          <div className="mb-2 flex items-center gap-2">
            <span className="grid size-5 place-items-center rounded-md bg-volt/15 text-[9px] font-extrabold text-volt">02</span>
            <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-cream">Pick your energy</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {SIGNATURE_COLORS.map((color) => {
              const selected = draft.color.toLowerCase() === color;
              return (
                <button
                  key={color}
                  type="button"
                  onClick={() => patch({ color })}
                  aria-label={`Use ${color}`}
                  aria-pressed={selected}
                  className="grid size-9 place-items-center rounded-full border-2 transition"
                  style={{ background: color, borderColor: selected ? "#f3f1e6" : "transparent" }}
                >
                  {selected && <Icon name="check" size={15} className="text-ink" strokeWidth={3} />}
                </button>
              );
            })}
            <label className="relative grid size-9 cursor-pointer place-items-center overflow-hidden rounded-full border-2 border-dashed border-line text-muted transition hover:border-cream/40">
              <Icon name="plus" size={14} />
              <input
                type="color"
                value={draft.color}
                onChange={(e) => patch({ color: e.target.value })}
                className="absolute inset-0 cursor-pointer opacity-0"
                aria-label="Custom signature colour"
              />
            </label>
            <span className="ml-auto font-mono text-[10px] uppercase tracking-[0.1em] text-muted/70">{draft.color}</span>
          </div>
        </div>

        <div>
          <div className="mb-2 flex items-center gap-2">
            <span className="grid size-5 place-items-center rounded-md bg-volt/15 text-[9px] font-extrabold text-volt">03</span>
            <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-cream">Design your celebration</p>
          </div>
          <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-7">
            {CELEBRATIONS.map((item) => {
              const selected = draft.celebration === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    patch({ celebration: item.id as CelebrationId });
                    setPulse((p) => p + 1);
                  }}
                  className="flex flex-col items-center gap-1 rounded-xl border px-1 py-2 transition"
                  style={{
                    borderColor: selected ? `${draft.color}99` : "#2a3027",
                    background: selected ? `${draft.color}12` : "rgba(0,0,0,0.2)",
                  }}
                  aria-pressed={selected}
                >
                  <span className="text-lg leading-none">{item.emoji}</span>
                  <span className="text-[7px] font-bold uppercase leading-tight tracking-wide text-muted">{item.name}</span>
                </button>
              );
            })}
          </div>
          <div className="mt-2 grid gap-2 sm:grid-cols-[1fr_auto]">
            <label className="block min-w-0">
              <span className="mb-1 block text-[8px] font-extrabold uppercase tracking-[0.16em] text-muted">Celebration name</span>
              <input
                value={draft.celebrationName}
                maxLength={24}
                onChange={(e) => patch({ celebrationName: e.target.value })}
                className="w-full rounded-lg border border-line bg-black/30 px-2.5 py-2 text-[12px] font-bold text-cream outline-none transition placeholder:text-muted/40 focus:border-volt/60"
                placeholder="Name the celebration"
              />
            </label>
            <div className="flex items-end gap-2">
              <button
                type="button"
                onClick={randomise}
                className="flex h-[36px] items-center gap-1.5 rounded-lg border border-line px-3 text-[9px] font-extrabold uppercase tracking-[0.12em] text-muted transition hover:border-volt/40 hover:text-volt"
              >
                <Icon name="spark" size={13} /> Remix
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {PRESETS.map((preset) => (
            <button
              key={preset.label}
              onClick={() => {
                setDraft(preset.signature);
                setPulse((p) => p + 1);
                setSaved(false);
              }}
              className="rounded-full border border-line bg-black/20 px-2.5 py-1 text-[9px] font-bold text-muted transition hover:border-cream/30 hover:text-cream"
            >
              {preset.label}
            </button>
          ))}
          <span className="ml-auto self-center text-[8px] uppercase tracking-[0.14em] text-muted/60">Start from a preset or go fully rogue</span>
        </div>
      </div>

      <div className="min-w-0">
        <div className="lg:sticky lg:top-0">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-[9px] font-extrabold uppercase tracking-[0.2em] text-volt">Locker room preview</p>
            <button
              onClick={() => setPulse((p) => p + 1)}
              className="flex items-center gap-1 text-[8px] font-extrabold uppercase tracking-[0.12em] text-muted transition hover:text-cream"
            >
              <Icon name="refresh" size={11} /> Replay
            </button>
          </div>
          <div
            key={pulse}
            className="animate-pop relative overflow-hidden rounded-3xl border p-5"
            style={{
              borderColor: `${draft.color}55`,
              background: `radial-gradient(120% 100% at 50% 0%, ${draft.color}22 0%, #0c120c 45%, #080c08 100%)`,
            }}
          >
            <div className="pitch-grid absolute inset-0 opacity-40" />
            <div
              className="pointer-events-none absolute -right-16 -top-20 size-64 rounded-full opacity-30 blur-3xl"
              style={{ background: draft.color }}
            />
            <div className="relative flex items-center justify-between">
              <span className="rounded-full border border-white/20 bg-black/30 px-2 py-1 text-[8px] font-extrabold uppercase tracking-[0.18em] text-muted">
                {effect.tag} / SIGNATURE
              </span>
              <span className="font-display text-xs text-muted">OVR {Math.min(99, 64 + (profile.wins ?? 0) * 2)}</span>

            </div>
            <div className="relative mt-3">
              <p className="font-display text-[clamp(2rem,5vw,3.25rem)] leading-[0.88] tracking-wide" style={{ color: draft.color }}>
                {draft.name.trim() || "UNTITLED MOVE"}
              </p>
              <p className="mt-1.5 text-[10px] font-bold uppercase tracking-[0.16em] text-cream/80">
                {effect.name} + {celebration.name}
              </p>
            </div>

            <div className="relative my-5 h-[190px] sm:h-[210px]">
              <div className="absolute inset-x-0 top-8 h-[60%] rounded-2xl border border-white/10 bg-[#0e1a11]/80">
                <div className="absolute inset-x-5 bottom-3 top-3 rounded-lg border border-white/10">
                  <div className="absolute inset-x-8 top-2 h-1/3 rounded border border-white/10" />
                  <div className="absolute left-1/2 top-1/2 size-12 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/10" />
                </div>
              </div>
              <div
                className="absolute left-1/2 top-[46%] grid size-[74px] -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border-4 border-[#0a0c09] font-display text-2xl text-ink shadow-2xl transition-transform duration-500 group-hover:scale-105"
                style={{ background: draft.color, boxShadow: `0 0 40px ${draft.color}66` }}
              >
                10
                <span className="absolute -bottom-3 rounded-full bg-[#0a0c09] px-2 py-0.5 text-[8px] font-extrabold uppercase tracking-[0.14em] text-cream">
                  {playerName.trim() || "YOU"}
                </span>
              </div>
              <div className="absolute right-[24%] top-[36%] size-4 rounded-full border-2 border-[#0a0c09] bg-cream shadow-lg" />
              <div
                className="absolute right-[17%] top-[18%] grid size-11 place-items-center rounded-xl border text-xl shadow-xl"
                style={{ background: "#0c120c", borderColor: `${draft.color}55` }}
              >
                {effect.icon}
              </div>
              <div className="absolute bottom-0 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/15 bg-[#0a0c09]/90 py-1 pl-1 pr-3">
                <span className="text-lg">{celebration.emoji}</span>
                <span className="whitespace-nowrap text-[8px] font-extrabold uppercase tracking-[0.16em] text-cream">
                  {draft.celebrationName.trim() || "Untitled celebration"}
                </span>
              </div>
            </div>

            <div className="relative grid grid-cols-3 gap-1.5">
              {[
                ["Power", effect.tag],
                ["Energy", draft.color],
                ["Rarity", "One of one"],
              ].map(([label, value]) => (
                <div key={label} className="rounded-lg border border-white/10 bg-black/25 px-2 py-1.5">
                  <p className="text-[7px] font-extrabold uppercase tracking-[0.14em] text-muted">{label}</p>
                  <p className="truncate font-display text-[11px] uppercase" style={{ color: label === "Energy" ? draft.color : undefined }}>
                    {value}
                  </p>
                </div>
              ))}
            </div>
            <p className="relative mt-3 text-[10px] leading-relaxed text-muted">{celebration.description}</p>
          </div>

          <div className="mt-3 space-y-2">
            <button
              onClick={test}
              disabled={!valid}
              className="group flex w-full items-center justify-between rounded-xl px-4 py-3 font-display text-[19px] tracking-wide text-ink transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
              style={{ background: draft.color }}
            >
              <span className="flex items-center gap-2">
                <Icon name="play" size={16} /> Test on the pitch
              </span>
              <Icon name="arrow" size={17} className="transition group-hover:translate-x-0.5" />
            </button>
            <div className="grid grid-cols-[1fr_auto] gap-2">
              <button
                onClick={save}
                disabled={!valid}
                className="flex items-center justify-center gap-2 rounded-xl border border-line bg-white/[0.04] py-2.5 text-[10px] font-extrabold uppercase tracking-[0.16em] text-cream transition hover:border-volt/50 disabled:opacity-40"
              >
                <Icon name={saved ? "check" : "star"} size={14} /> {saved ? "Saved to profile" : "Save signature"}
              </button>
              <button
                onClick={onClose}
                className="rounded-xl border border-line px-3 py-2.5 text-[10px] font-extrabold uppercase tracking-[0.12em] text-muted transition hover:text-cream"
              >
                Close
              </button>
            </div>
            {!valid && (
              <p className="text-center text-[9px] font-bold uppercase tracking-[0.1em] text-coral">
                Add a tag, skill name and celebration name to lock it in
              </p>
            )}
            <p className="text-center text-[8px] uppercase tracking-[0.12em] text-muted/60">
              Signature charges during play · tap the glowing button in a match
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}


