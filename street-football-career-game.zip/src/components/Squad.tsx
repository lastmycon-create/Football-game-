import { TEAMMATES, formatNumber, levelForXp, type Profile, type Teammate } from "../lib/data";
import { Icon } from "./Icons";

interface SquadProps {
  profile: Profile;
  onRecruit: (teammate: Teammate) => void;
  onEquip: (teammate: Teammate) => void;
  onPlay: () => void;
}

export function Squad({ profile, onRecruit, onEquip, onPlay }: SquadProps) {
  const level = levelForXp(profile.xp);
  const owned = TEAMMATES.filter((t) => profile.teammates.includes(t.id));
  const active = TEAMMATES.find((t) => t.id === profile.activeTeammate);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-black/20 p-4">
        <div className="flex items-center gap-3">
          <div className="grid size-11 place-items-center rounded-xl bg-volt/10 text-volt">
            <Icon name="users" size={22} />
          </div>
          <div>
            <p className="text-[9px] font-extrabold uppercase tracking-[0.2em] text-muted">The crew</p>
            <p className="font-display text-xl leading-tight">
              {owned.length} <span className="text-muted">/ {TEAMMATES.length} recruited</span>
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 rounded-full border border-gold/25 bg-gold/10 px-2.5 py-1.5 text-[11px] font-extrabold text-gold">
            <Icon name="coin" size={13} /> {formatNumber(profile.coins)}
          </span>
          <span className="rounded-full border border-line bg-ink-3 px-2.5 py-1.5 text-[10px] font-extrabold uppercase tracking-[0.1em] text-muted">
            Level {level}
          </span>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between gap-3 rounded-xl border border-volt/20 bg-volt/[0.06] px-3 py-2.5">
        <p className="text-[10px] font-bold text-cream">
          <span className="text-volt">ACTIVE:</span> {active ? `${active.name} · ${active.boostLabel}` : "No one equipped"}
        </p>
        <button
          onClick={onPlay}
          className="flex shrink-0 items-center gap-1 text-[9px] font-extrabold uppercase tracking-[0.14em] text-volt transition hover:text-cream"
        >
          Test squad <Icon name="arrow" size={12} />
        </button>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {TEAMMATES.map((mate) => {
          const isOwned = profile.teammates.includes(mate.id);
          const isActive = profile.activeTeammate === mate.id;
          const lockedByLevel = level < mate.unlockLevel;
          const canAfford = profile.coins >= mate.cost;
          return (
            <article
              key={mate.id}
              className={`group relative overflow-hidden rounded-2xl border p-3.5 transition sm:p-4 ${
                isActive ? "border-volt/60 bg-volt/[0.06]" : "border-line bg-black/20 hover:border-white/20"
              }`}
            >
              <div
                className="pointer-events-none absolute -right-12 -top-12 size-32 rounded-full opacity-[0.14] blur-2xl transition group-hover:opacity-25"
                style={{ background: mate.color }}
              />
              <div className="relative flex items-start gap-3">
                <div
                  className="relative grid size-12 shrink-0 place-items-center rounded-xl font-display text-lg"
                  style={{ background: `${mate.color}1c`, border: `1px solid ${mate.color}55`, color: mate.color }}
                >
                  {mate.initials}
                  <span className="absolute -bottom-1 -right-1 rounded bg-ink px-1 text-[7px] font-extrabold text-muted">
                    {mate.statLabel} {mate.stat}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate font-display text-lg leading-tight">{mate.name}</p>
                      <p className="text-[9px] font-extrabold uppercase tracking-[0.16em] text-muted">
                        {mate.role} · {mate.boostLabel}
                      </p>
                    </div>
                    {isActive && (
                      <span className="shrink-0 rounded-full bg-volt px-1.5 py-0.5 text-[8px] font-extrabold uppercase tracking-wider text-ink">
                        Active
                      </span>
                    )}
                  </div>
                  <p className="mt-1.5 text-[10px] leading-relaxed text-muted">{mate.boostDesc}</p>
                  <div className="mt-2.5 flex items-center justify-between gap-2">
                    <span className="text-[9px] font-bold uppercase tracking-[0.1em] text-muted/70">
                      {isOwned ? "Signed to your block" : lockedByLevel ? `Unlocks at level ${mate.unlockLevel}` : `${mate.cost} coins`}
                    </span>
                    {isOwned ? (
                      <button
                        onClick={() => onEquip(mate)}
                        disabled={isActive}
                        className={`rounded-full border px-3 py-1 text-[9px] font-extrabold uppercase tracking-[0.12em] transition ${
                          isActive
                            ? "cursor-default border-volt/40 bg-volt/15 text-volt"
                            : "border-line text-cream hover:border-volt/60 hover:text-volt"
                        }`}
                      >
                        {isActive ? "Equipped" : "Equip"}
                      </button>
                    ) : (
                      <button
                        onClick={() => onRecruit(mate)}
                        disabled={lockedByLevel || !canAfford}
                        className="flex items-center gap-1 rounded-full bg-volt px-3 py-1 text-[9px] font-extrabold uppercase tracking-[0.12em] text-ink transition hover:bg-volt-dim disabled:cursor-not-allowed disabled:bg-white/10 disabled:text-muted"
                      >
                        {lockedByLevel ? <Icon name="lock" size={11} /> : <Icon name="plus" size={11} />}
                        {lockedByLevel ? "Locked" : canAfford ? "Recruit" : "Need coins"}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </article>
          );
        })}
      </div>
      <p className="mt-3 text-center text-[9px] uppercase tracking-[0.14em] text-muted/60">
        Earn coins by playing matches. Every teammate changes how the game feels.
      </p>
    </div>
  );
}
